# AI Guardrails for Financial UX

A free kit for product teams putting an AI assistant on a live financial screen: trading, wealth, payments or banking. Seven rules, a one-page checklist, and Claude skills that run the review for you.

By Rick Hollandsworth, Principal Product Designer. Worked example: the FinFront AI Assistant case study at rickhollandsworth.com/ai. FinFront is a self-directed prototype with synthetic data; the case study shows design decisions, not usage results.

## The seven rules

1. **Never block the data.** The assistant never covers or reflows live numbers.
2. **Stage, never execute.** It drafts into the product's own form; the consequential button is the user's.
3. **Show your sources.** Answers in the product's units, naming what was read and when, with stated assumptions.
4. **Suggest what fits the screen.** Suggestions follow the current screen and role.
5. **Get noticed only when it matters.** Signals only for something new, never while the user is focused.
6. **One pattern, every desk.** One assistant everywhere; role and permissions decide what it can see.
7. **Stay interruptible.** Plain progress steps, Stop where Send was, and visible failures with a way forward.

## What's inside

- `AI-Guardrails-Checklist.pdf`: 23 yes/no questions for a design review. Every "no" is a finding.
- `skills/guardrails-review/`: runs the full review against all seven rules. Start here.
- `skills/guardrail-*/`: one skill per rule, for a deeper look at a single rule.

## Using the skills

Add a skill folder to Claude as a skill (each folder has a `SKILL.md`). Then share screenshots, a spec, flows or sample answers of your assistant and ask Claude to "run a guardrails review". It returns a status per rule, the top three fixes, and a table of every check with evidence.

## When to break general chat-UI rules

On a live financial screen, three common chat patterns bend: no side rail (it takes a column of live data), no AI execute button even behind a confirm dialog, and one quiet signal that means "the assistant" is fine if it never moves while idle.

Free to use and share with credit. Questions or a walkthrough: rick.hollandsworth@outlook.com or message Rick on LinkedIn.
