---
name: guardrail-never-block-data
description: Reviews an AI assistant on a live financial screen for Rule 1, Never block the data. Use when given screenshots, a layout spec or a prototype of an assistant panel in a trading, wealth, payments or banking product, to check that the assistant never covers or reflows live numbers.
---

# Rule 1: Never block the data

On a live financial screen the data is the product. The assistant is a guest on it. It must never cover, push aside or reflow live numbers, and the user must be able to get it out of the way instantly.

## What to ask for
- Screenshots of the screen with the assistant closed, open, and at its largest size
- How the panel is placed (floating, docked, modal, side rail) and how it is moved, minimised and dismissed
- Any layout rules: what happens to the screen underneath when the panel opens

If a screenshot pair (closed vs open) is missing, say so and mark the layout questions "Can't tell".

## Checks
1. Is every live number still visible with the assistant open? Compare closed and open screenshots column by column.
2. Can it be moved, minimised and dismissed in one action each? Name the control for each.
3. Does opening or moving it leave the layout underneath unchanged? Any column, row or widget that shifts, shrinks or disappears is a fail.

## Common failures
- A docked side rail that takes a price or order column with it
- A modal or overlay that greys out the screen while the assistant answers
- A panel that re-centres or grows when an answer arrives, covering data the user was watching

## What good looks like
FinFront's assistant is a floating panel, not a docked column. Drag it by the title bar, minimise it to one row, close and reopen it with one key, and it remembers its position per user. The ladder underneath never loses a column.

## When the general rule bends
General chat guidance recommends a split-pane canvas (chat rail plus a deliverable pane). On a live screen, don't use one: it takes columns of live data. Put deliverables in the product's own form or ticket instead (see Rule 2).

## Output
Return a table with one row per check: Check · Pass / Fail / Can't tell · Evidence (what you saw, where) · Fix (one sentence, specific). End with the single most important fix. No preamble.
