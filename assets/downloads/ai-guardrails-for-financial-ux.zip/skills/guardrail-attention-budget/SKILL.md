---
name: guardrail-attention-budget
description: Reviews an AI assistant's motion, badges and notifications in a financial product for Rule 5, Get noticed only when it matters. Use when given motion specs, notification rules or screen recordings, to check that the assistant draws attention only for something new and never distracts a user who is focused.
---

# Rule 5: Get noticed only when it matters

On a live screen, attention is the scarcest resource. The assistant earns a glance only when it has something new, and never while the user is reading or acting.

## What to ask for
- Every animation, badge, sound and notification the assistant can produce, with its trigger
- What happens when a reply lands while the user is looking elsewhere, and when the panel is closed

## Checks
1. Does it signal only when there is something new?
2. Does it stay still when the user is focused on it, and when idle?
3. Is an unread reply held quietly until the user returns?

## Common failures
- A shimmering or pulsing assistant icon while idle
- A toast or sound for every reply, including ones the user is already watching
- Motion that keeps playing while the user is reading the answer

## What good looks like
FinFront's blue-to-green border beats twice on open and once when a reply lands, only if the user isn't already looking: one ring, 0 to 26 px as it fades, 1.2 s, once, skipped if the panel has focus or the cursor. Closed, one static amber dot on the assistant button holds the unread reply. There is no idle animation.

## When the general rule bends
General guidance reserves accent color for focus and links. One quiet signal that means "the assistant" is acceptable on a live screen, if it never moves while idle and is the assistant's only attention cue.

## Output
Table: Check · Pass / Fail / Can't tell · Evidence · Fix. List every trigger that fires while the user is focused. No preamble.
