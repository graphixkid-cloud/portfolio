---
name: guardrail-one-pattern
description: Reviews an AI assistant across several products, desks, roles or themes for Rule 6, One pattern, every desk. Use when given screenshots of the assistant in more than one product or role, to check that it is the same panel and promise everywhere and that role and permissions, not the UI, decide what it can see and do.
---

# Rule 6: One pattern, every desk

Users who move between products or roles should meet the same assistant, with the same promise. Only what it can read and stage should change.

## What to ask for
- Screenshots of the assistant in each product or desk, and in each theme
- How role or permission changes affect what it can see and stage

## Checks
1. Is it the same panel, header, opening line and footer across products?
2. Do role and permissions decide what it can read and stage?
3. Does it use the product's design tokens, in both themes?

## Common failures
- A different assistant per product team, each with its own layout and tone
- An assistant that can read data the user's role can't see on screen
- A dark-mode panel with hard-coded light colors

## What good looks like
FinFront's FX, Prop, RIA, CRE and Commodities desks share one assistant: same panel, header and context chip, same first message, same promise ("I can read … for the role you are viewing as, and stage … for you to confirm. I never execute."). The role chip in the top bar decides what it can see; switching roles switches its context, chips and permissions. One shared guardrails layer runs on all five, so sources, read time, steps, Stop and the failure state behave identically in both themes.

## Output
Table: Check · Pass / Fail / Can't tell · Evidence (name the product and role) · Fix. List every inconsistency between products as its own line. No preamble.
