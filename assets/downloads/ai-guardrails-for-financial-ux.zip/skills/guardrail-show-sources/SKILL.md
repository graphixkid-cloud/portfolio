---
name: guardrail-show-sources
description: Reviews AI assistant answers in a financial product for Rule 3, Show your sources. Use when given sample answers, screenshots or an answer spec, to check that answers use the product's own numbers and units, name what they read and when, link back to where each number lives, and state their assumptions.
---

# Rule 3: Show your sources

An answer a trader or advisor can't verify is an answer they can't act on. Answers come back in the product's own numbers, say what they read and when, and lead back to where each number lives.

## What to ask for
- 3–5 sample answers covering different question types (a lookup, a calculation, a comparison)
- Screenshots of how sources are shown, and what happens on hover or click
- How the product handles stale, partial or estimated data

## Checks
1. Are answers in the product's own numbers and units, not prose? Structured data should come back as a table, card or meter.
2. Does each answer name the data it read, and when it read it? Look for source labels and an "as of" time on every answer.
3. Can the user preview a source and jump from any number to where it lives?
4. Are stale, partial or estimated inputs called out in one line, not buried in prose?

## Common failures
- Three paragraphs where a five-row table would do
- A generic "Sources" footnote with no time, so a correct number from 40 seconds ago looks current
- Caveats hidden mid-paragraph ("note that some data may be delayed")
- Using the same color for "assumption" as for another state, so neither reads clearly

## What good looks like
FinFront answers "Which positions are closest to limit?" with a table in the risk screen's units: net, limit use and a meter per line. Under it, "grounded in" names each source and the read time ("as of 10:52:07 ET"). Hovering a source shows rows read, read time and where it lives, with Show on desk; each table row keeps a focus link. Stale, partial or estimated inputs get one muted info line, never amber, which means staged.

## Output
Table: Check · Pass / Fail / Can't tell · Evidence (quote the answer) · Fix. If an answer is prose that should be a component, sketch the columns it should have. No preamble.
