---
name: guardrail-context-suggestions
description: Reviews an AI assistant's suggestions and starter prompts in a financial product for Rule 4, Suggest what fits the screen. Use when given screenshots of prompt chips, zero states or follow-ups across screens or roles, to check that suggestions follow the user's current context instead of a fixed menu.
---

# Rule 4: Suggest what fits the screen

Users rarely know what an assistant can do. Suggestions should come from where they are and who they are, not from a static menu.

## What to ask for
- The empty state and starter suggestions on at least two different screens or roles
- Follow-up suggestions after two or three different answers
- How the current context is shown in the assistant

## Checks
1. Do suggestions change with the current context (screen, instrument, account, role)?
2. Are suggestions limited to actions possible on this screen for this role?
3. Is the current context shown, so users know why they see these suggestions?

## Common failures
- The same five generic prompts everywhere ("Summarize", "Explain", "What can you do?")
- Suggesting an action the user's role can't perform
- A blank box with "How can I help?" and nothing else

## What good looks like
FinFront's prompt chips follow the context chip in the panel header. Trade · Majors offers hedges, rolls and RFQs for the pairs on screen; Reports offers audit trails and fill rates. After every answer, 1–3 follow-ups suggest the next step.

## Output
Table: Check · Pass / Fail / Can't tell · Evidence · Fix. For any static suggestion set, propose 3 context-aware replacements for one specific screen. No preamble.
