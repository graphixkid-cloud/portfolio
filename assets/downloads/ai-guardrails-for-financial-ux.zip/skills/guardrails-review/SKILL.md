---
name: guardrails-review
description: Runs a full AI Guardrails for Financial UX review of an AI assistant in a trading, wealth, payments or banking product, against all seven rules. Use when someone asks to review, audit or critique an AI assistant, copilot or chat feature in a financial product, or shares screenshots, specs or a prototype of one.
---

# AI Guardrails for Financial UX: full review

Review the assistant against the seven rules below, in order, using the checklist questions. Each rule has its own skill with more detail; follow the same checks here.

1. **Never block the data:** the assistant never covers or reflows live numbers, and can be moved, minimised and dismissed in one action each.
2. **Stage, never execute:** actions are drafted into the product's own form; the consequential button is the user's; staged changes show a before and after.
3. **Show your sources:** answers in the product's units, naming what was read and when, with source previews, links back and a one-line assumptions note.
4. **Suggest what fits the screen:** suggestions follow the current screen and role, and the context is shown.
5. **Get noticed only when it matters:** signals only for something new, never while the user is focused, never while idle.
6. **One pattern, every desk:** same panel and promise everywhere; role and permissions decide what it can read and stage.
7. **Stay interruptible:** plain progress steps, Stop where Send was, a steady layout, and visible failures with a way forward.

## How to run it
1. List the materials provided (screenshots, specs, flows, sample answers) and what is missing. Ask for missing materials only if a whole rule can't be judged; otherwise mark those checks "Can't tell".
2. Judge each checklist question: Pass, Fail or Can't tell, with evidence from the materials. Don't assume something exists because it would be sensible.
3. Note where the product deliberately departs from general chat-UI guidance (no side rail, no AI execute control, one quiet attention signal). These are acceptable on a live financial screen when the reason holds; don't count them as fails.

## Output
1. **Summary:** one line per rule with a status (Pass / Partial / Fail / Can't tell).
2. **Top three fixes,** in priority order, each one sentence and specific to this product.
3. **Full table:** Rule · Check · Status · Evidence · Fix.

Keep it compressed: tables and short sentences, no preamble, no closing summary.

The worked example for every rule is the FinFront AI Assistant case study by Rick Hollandsworth (rickhollandsworth.com/ai), a self-directed prototype with synthetic data. It shows design decisions, not usage results.
