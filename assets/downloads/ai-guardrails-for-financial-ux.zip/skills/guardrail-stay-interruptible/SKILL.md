---
name: guardrail-stay-interruptible
description: Reviews an AI assistant's working, streaming and error states in a financial product for Rule 7, Stay interruptible. Use when given loading states, streaming behavior, error screens or recordings, to check that the assistant shows what it is doing, can be stopped at once, keeps the layout steady and fails visibly with a way forward.
---

# Rule 7: Stay interruptible

AI is slow and sometimes fails. The user should never wonder whether it is working, should be able to stop it instantly, and should see exactly what failed.

## What to ask for
- The state between sending a request and the answer arriving
- What happens on stop, on a slow source, and on a failed source
- A recording or before/after screenshots of an answer streaming in

## Checks
1. While it works, does it show what it is doing in plain steps tied to real reads? A generic spinner is a fail.
2. Can the user stop it at once, with the control where Send was? Keyboard stop (Esc) is a plus.
3. When a source is unavailable or slow, does it say so and offer a way forward (retry, or continue without it and say so), with the layout unchanged?

Also check that content arriving doesn't shift the layout: tables and cards should hold their final size from the start.

## Common failures
- Pulsing dots for 8+ seconds with no explanation
- No way to stop a long answer except closing the panel
- Tables popping in and pushing the screen down as they stream
- A silent failure, or a generic "Something went wrong"

## What good looks like
In FinFront, each working step names a real read and ticks when done, and a skeleton holds the final height so nothing moves. Send becomes Stop in the same place, and Esc stops too; whatever already landed stays, labelled Stopped. If a source fails or takes longer than 8 seconds: "Couldn't read Positions (timed out)." with Retry, or answer without it, which adds an assumptions line.

## Output
Table: Check · Pass / Fail / Can't tell · Evidence · Fix. For a missing progress state, write the 2–3 step labels it should show. No preamble.
