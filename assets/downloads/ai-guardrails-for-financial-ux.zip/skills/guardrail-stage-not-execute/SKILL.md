---
name: guardrail-stage-not-execute
description: Reviews an AI assistant in a financial product for Rule 2, Stage, never execute. Use when given flows, screenshots or specs of what the assistant can do, to check that it drafts actions into the product's real forms and never submits, sends, trades or confirms on the user's behalf.
---

# Rule 2: Stage, never execute

The assistant drafts and stops. The consequential button, the one that sends money, places an order or changes a record, belongs to the person who answers for it.

## What to ask for
- Every action the assistant can prepare, end to end, from prompt to the final button
- Screenshots of staged drafts and the form or ticket they hand off to
- The copy the interface uses to describe what the assistant can and can't do

## Checks
1. Does every action the assistant prepares end in the product's own form or ticket, pre-filled? A separate "AI version" of a form is a fail.
2. Is the final, consequential button pressed only by the user? Any path where the assistant submits, sends, books or confirms is a fail.
3. Does the interface say, in plain words, that the assistant never executes? Look for it in the opening line and a persistent footer.
4. Do staged changes show a before and after? This applies to anything that would change a layout, setting or record.

## Common failures
- "Submit for me" or "Execute" inside the chat
- A confirmation dialog that lets the AI act after one click, which users learn to approve by reflex
- A generic chat form that asks for fields the product already knows

## What good looks like
In FinFront, asking for an RFQ produces a staged card (pair, amount, tenor, Tier-1 LPs, indicative points). "Open RFQ" loads the desk's own ticket, pre-filled. SEND stays a human button, and the panel footer reads "the assistant never executes" on every screen.

## When the general rule bends
General guidance gates high-stakes AI actions with a Confirm/Cancel card. For money and orders, go further: give the assistant no execute control at all. Then there is nothing to approve by reflex.

## Output
Table: Check · Pass / Fail / Can't tell · Evidence · Fix. List every path you found that ends in an AI-initiated action, even if the other checks pass. No preamble.
